import { d as defineEventHandler, r as readBody, u as useRuntimeConfig } from '../../nitro/nitro.mjs';
import OpenAI from 'openai';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const generateChart = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const body = await readBody(event);
  const prompt = body.prompt;
  const chartLib = body.chartLib;
  const chartType = body.chartType;
  const aiCodeStr = body.aiCodeStr;
  const config = useRuntimeConfig();
  const openai = new OpenAI({
    apiKey: config.dashscopeApiKey,
    baseURL: "https://dashscope.aliyuncs.com/compatible-mode/v1"
  });
  const completion = await openai.chat.completions.create({
    model: "qwen-coder-plus",
    messages: [
      {
        role: "system",
        content: `
\u4F60\u662F\u4E00\u4E2A\u524D\u7AEF\u56FE\u8868\u914D\u7F6E\u751F\u6210\u5668\uFF0C\u8BF7\u4E25\u683C\u6839\u636E\u7528\u6237\u9700\u6C42\uFF0C\u82E5\u5DF2\u6709\u56FE\u8868\u914D\u7F6E\uFF0C\u5219\u5728\u5DF2\u6709\u56FE\u8868\u914D\u7F6E\u4E0A\u8FDB\u884C\u6700\u5C0F\u5FC5\u8981\u6539\u52A8\uFF0C\u751F\u6210\u65B0\u7684\u56FE\u8868\u7684\u914D\u7F6E option\u3002

# \u8981\u6C42\uFF1A
- \u56FE\u8868\u5E93\uFF1A${chartLib}
- \u56FE\u8868\u7C7B\u578B\uFF1A${chartType}
${aiCodeStr ? "- \u8FD9\u662F\u4E4B\u524D\u7684\u56FE\u8868\u914D\u7F6E\uFF1A" + aiCodeStr + "\uFF0C\u5728\u5DF2\u6709\u914D\u7F6E\u7684\u57FA\u7840\u4E0A\u7EE7\u7EED\u4FEE\u6539" : ""}
- \u4E25\u7981\u968F\u610F\u66F4\u6362\u56FE\u8868\u6570\u636E\u6216\u7ED3\u6784\u3002
- \u4EC5\u6839\u636E\u7528\u6237\u65B0\u63CF\u8FF0\u505A\u5FC5\u8981\u8C03\u6574\u3002

# \u8F93\u51FA\u683C\u5F0F\uFF08\u4E00\u4E2A\u5408\u6CD5\u7684 JavaScript \u5BF9\u8C61\uFF08\u4E0D\u662F JSON\uFF09\u3002\u5141\u8BB8\u5305\u542B\u51FD\u6570\uFF0C\u6BD4\u5982 symbolSize\u3001formatter \u7B49\uFF09\uFF1A

\u{1F6AB} \u4E25\u7981\u8F93\u51FA\u4EFB\u4F55\u89E3\u91CA\u3001\u6CE8\u91CA\u3001\u8BF4\u660E\u3001Markdown\u4EE3\u7801\u5757\u6216\u683C\u5F0F\u5316\u63D0\u793A\uFF01

\u2705 \u53EA\u8F93\u51FA\u7EAF JS \u5BF9\u8C61\uFF0C\u5F62\u5982\uFF1A

{ ...\u5B8C\u6574\u56FE\u8868\u914D\u7F6E... }

      `.trim()
      },
      {
        role: "user",
        content: `\u7528\u6237\u9700\u6C42\uFF1A${prompt}`
      }
    ],
    temperature: 0.3
  });
  const result = (_d = (_c = (_b = (_a = completion.choices) == null ? void 0 : _a[0]) == null ? void 0 : _b.message) == null ? void 0 : _c.content) != null ? _d : "{}";
  return result;
});

export { generateChart as default };
//# sourceMappingURL=generateChart.mjs.map
